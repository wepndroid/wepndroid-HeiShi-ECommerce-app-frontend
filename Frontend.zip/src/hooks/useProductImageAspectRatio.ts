import { useEffect, useState } from 'react';
import { Image } from 'react-native';
import type { ProductHeight } from '../types';

const MIN_ASPECT = 0.58;
const MAX_ASPECT = 0.92;

function clampAspectRatio(ratio: number): number {
  return Math.min(MAX_ASPECT, Math.max(MIN_ASPECT, ratio));
}

/** Stable fallback before image dimensions load — varies by listing id and height tier. */
export function fallbackCardAspectRatio(height: ProductHeight, productId: number): number {
  const baseHeight = height === 'tall' ? 8.8 : height === 'short' ? 6.15 : 7;
  const variedHeight = baseHeight + ((productId * 17) % 10) * 0.11;
  return clampAspectRatio(5 / variedHeight);
}

export function useProductImageAspectRatio(
  imageUrl: string,
  height: ProductHeight,
  productId: number,
): number {
  const fallback = fallbackCardAspectRatio(height, productId);
  const [aspectRatio, setAspectRatio] = useState(fallback);

  useEffect(() => {
    setAspectRatio(fallback);
    if (!imageUrl) return;

    let cancelled = false;
    Image.getSize(
      imageUrl,
      (width, heightPx) => {
        if (cancelled || width <= 0 || heightPx <= 0) return;
        setAspectRatio(clampAspectRatio(width / heightPx));
      },
      () => {
        if (!cancelled) setAspectRatio(fallback);
      },
    );

    return () => {
      cancelled = true;
    };
  }, [imageUrl, fallback, height, productId]);

  return aspectRatio;
}