import { useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { MAX_LISTING_PHOTOS, pickImagesFromLibrary } from '../services/mediaPicker';
import { uploadListingImage } from '../services/listingsService';

export function useListingPhotos(isLoggedIn: boolean, onToast: (message: string) => void) {
  const { t } = useTranslation();
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);

  const addPhotosFromLibrary = useCallback(async () => {
    if (uploading) return;
    const remaining = MAX_LISTING_PHOTOS - imageUrls.length;
    if (remaining <= 0) {
      onToast(t('toast.photoLimit', { count: MAX_LISTING_PHOTOS }));
      return;
    }

    setUploading(true);
    try {
      const picked = await pickImagesFromLibrary({
        max: remaining,
        allowsMultiple: remaining > 1,
      });
      if (!picked.length) return;

      const uploaded: string[] = [];
      for (const asset of picked) {
        const url = await uploadListingImage(
          asset.uri,
          isLoggedIn,
          asset.mimeType,
          asset.fileName,
        );
        uploaded.push(url);
      }
      setImageUrls((prev) => [...prev, ...uploaded]);
      onToast(t('toast.photoAdded'));
    } catch (error) {
      if (error instanceof Error && error.message === 'permission_denied') {
        onToast(t('toast.mediaPermissionDenied'));
      } else {
        onToast(t('toast.uploadFailed'));
      }
    } finally {
      setUploading(false);
    }
  }, [imageUrls.length, isLoggedIn, onToast, t, uploading]);

  return {
    imageUrls,
    setImageUrls,
    uploading,
    addPhotosFromLibrary,
    maxPhotos: MAX_LISTING_PHOTOS,
  };
}