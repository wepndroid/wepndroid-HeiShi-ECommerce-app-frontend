import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Text } from '../components/typography';
import { useTranslation } from 'react-i18next';
import { useApp } from '../context/AppContext';
import { useConversations } from '../hooks/useConversations';
import { useNotificationGroups } from '../hooks/useNotificationGroups';
import { openMessageGroup } from './MessageGroupScreen';
import { AppIcon } from '../components/AppIcon';
import { IconButton, Notice, ScreenScroll, SearchBar, TitleBar } from '../components/UI';
import { ListCard } from '../components/FormUI';
import { SellerAvatar } from '../components/SellerAvatar';
import { colors, fonts } from '../theme';

function formatTimeLabel(timeLabel: string, t: (key: string) => string): string {
  if (timeLabel === '__YESTERDAY__') return t('screens.messages.yesterday');
  return timeLabel;
}

const GROUP_TITLE_KEYS = {
  system: 'screens.messages.systemTitle',
  order: 'screens.messages.orderTitle',
  follow: 'screens.messages.followTitle',
} as const;

export function MessagesScreen() {
  const { t } = useTranslation();
  const { nav, toast, openChat, openSellerProfile, isLoggedIn, authReady } = useApp();
  const { conversations } = useConversations(isLoggedIn, authReady);
  const { groups } = useNotificationGroups(isLoggedIn, authReady);

  return (
    <ScreenScroll screenId="messages">
      <TitleBar
        title={t('screens.messages.title')}
        right={
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <IconButton icon="bell" onPress={() => toast(t('toast.notificationsEnabled'))} />
            <IconButton icon="settings" onPress={() => nav('settings')} />
          </View>
        }
      />
      <Notice
        text={t('screens.messages.notice')}
        action={t('common.enable')}
        onAction={() => toast(t('toast.notificationsEnabled'))}
      />
      <SearchBar placeholder={t('screens.messages.searchPlaceholder')} readonly />
      <ListCard>
        {groups.map((row, index) => (
          <Pressable
            key={row.category}
            style={[styles.messageRow, index < groups.length - 1 && styles.messageBorder]}
            onPress={() => openMessageGroup(row.category)}
          >
            <View style={styles.messageAvatar}>
              <AppIcon name={row.icon} size={22} color="#b87000" />
              {row.unreadCount > 0 ? (
                <View style={styles.unread}>
                  <Text style={styles.unreadText}>{row.unreadCount}</Text>
                </View>
              ) : null}
            </View>
            <View style={styles.messageInfo}>
              <Text style={styles.messageTitle}>{t(GROUP_TITLE_KEYS[row.category])}</Text>
              <Text style={styles.messageMsg} numberOfLines={1}>
                {row.previewBody || row.previewTitle}
              </Text>
            </View>
            <Text style={styles.time}>{formatTimeLabel(row.timeLabel, t)}</Text>
          </Pressable>
        ))}
      </ListCard>
      <ListCard>
        {conversations.map((row, index) => (
          <Pressable
            key={row.id}
            style={[styles.messageRow, index < conversations.length - 1 && styles.messageBorder]}
            onPress={() =>
              openChat({
                conversationId: row.id,
                counterpartName: row.counterpartName,
                listingId: row.listingId,
              })
            }
          >
            <Pressable
              style={styles.messageAvatar}
              onPress={() => openSellerProfile(row.counterpartKey)}
            >
              <SellerAvatar
                sellerKey={row.counterpartKey}
                seller={row.counterpartName}
                avatarUrl={row.counterpartAvatarUrl}
                size={44}
              />
              {row.unreadCount > 0 ? (
                <View style={styles.unread}>
                  <Text style={styles.unreadText}>{row.unreadCount}</Text>
                </View>
              ) : null}
            </Pressable>
            <View style={styles.messageInfo}>
              <Text style={styles.messageTitle}>
                {row.counterpartName}
                {row.verified ? ` ${t('common.verifiedBadge')}` : ''}
              </Text>
              <Text style={styles.messageMsg} numberOfLines={1}>
                {row.lastMessage}
              </Text>
            </View>
            <Text style={styles.time}>{row.timeLabel}</Text>
          </Pressable>
        ))}
      </ListCard>
    </ScreenScroll>
  );
}

const styles = StyleSheet.create({
  messageRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    paddingHorizontal: 14,
  },
  messageBorder: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.line,
  },
  messageAvatar: {
    width: 44,
    height: 44,
    position: 'relative',
  },
  unread: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  unreadText: {
    fontFamily: fonts.bold,
    fontSize: 10,
    color: colors.phoneBorder,
  },
  messageInfo: {
    flex: 1,
    gap: 2,
  },
  messageTitle: {
    fontFamily: fonts.medium,
    fontSize: 15,
    color: colors.text,
  },
  messageMsg: {
    fontFamily: fonts.regular,
    fontSize: 13,
    color: colors.muted,
  },
  time: {
    fontFamily: fonts.regular,
    fontSize: 12,
    color: colors.muted,
  },
});
