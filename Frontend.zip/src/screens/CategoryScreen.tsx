import React from 'react';
import { Image, Pressable, ScrollView, StyleSheet } from 'react-native';
import { Text } from '../components/typography';
import { useTranslation } from 'react-i18next';
import { useApp } from '../context/AppContext';
import { serviceDetailProduct } from '../data/detailProducts';
import type { LocalService } from '../data/services';
import { useCatalogServices } from '../hooks/useCatalogServices';
import { homeFilterForCategory } from '../hooks/useProductFilters';
import { HOME_CATEGORY_ICONS } from '../assets/homeCategories';
import {
  ScreenScroll,
  SearchBar,
  SectionHead,
  TitleBar,
} from '../components/UI';
import { Banner, ServiceCard } from '../components/ProductUI';
import { AmazingSurface } from '../components/AmazingSurface';
import { ProductCatKey } from '../types';
import { fonts, filterIconLabelColor, radius } from '../theme';

const CATS: { catKey: keyof typeof HOME_CATEGORY_ICONS; labelKey: string }[] = [
  { catKey: 'digital', labelKey: 'homeCats.digital' },
  { catKey: 'home', labelKey: 'homeCats.home' },
  { catKey: 'fashion', labelKey: 'homeCats.fashion' },
  { catKey: 'beauty', labelKey: 'homeCats.beauty' },
];

export function CategoryScreen() {
  const { t } = useTranslation();
  const { nav, openSearch, openDetail, region, products, setHomeCategory, setHomeTabKey, homeTabKey } = useApp();
  const { services: visibleServices } = useCatalogServices(region);

  const openServiceDetail = (service: LocalService) => {
    openDetail(
      serviceDetailProduct(service, service.imageUrl ?? products[0]?.imageUrl ?? ''),
    );
  };

  const filterCat = (catKey: ProductCatKey) => {
    const { tab, category } = homeFilterForCategory(catKey, homeTabKey);
    setHomeTabKey(tab);
    setHomeCategory(category);
    nav('home');
  };

  return (
    <ScreenScroll screenId="category">
      <TitleBar title={t('nav.category')} />
      <SearchBar
        placeholder={t('screens.category.searchPlaceholder')}
        readonly
        onPress={openSearch}
      />
      <Banner
        title={t('screens.category.bannerTitle')}
        subtitle={t('screens.category.bannerSubtitle')}
        icon="mapPin"
      />
      <SectionHead title={t('screens.category.sectionCategories')} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.catRow}>
        {CATS.map((cat) => (
          <Pressable key={cat.catKey} style={styles.cat} onPress={() => filterCat(cat.catKey)}>
            <Image
              source={HOME_CATEGORY_ICONS[cat.catKey]}
              style={styles.catImage}
              resizeMode="contain"
            />
            <Text style={styles.catLabel} numberOfLines={2}>
              {t(cat.labelKey)}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
      <SectionHead title={t('screens.category.sectionServices')} action={t('screens.category.featured')} />
      {visibleServices.length ? (
        visibleServices.map((service) => (
          <ServiceCard
            key={service.id}
            service={service}
            onPress={() => openServiceDetail(service)}
          />
        ))
      ) : (
        <AmazingSurface style={styles.empty}>
          <Text style={styles.emptyText}>{t('screens.category.emptyServices')}</Text>
        </AmazingSurface>
      )}
    </ScreenScroll>
  );
}

const styles = StyleSheet.create({
  catRow: {
    paddingVertical: 4,
    paddingHorizontal: 0,
    marginBottom: 8,
  },
  cat: {
    minWidth: 52,
    alignItems: 'center',
    marginRight: 10,
  },
  catImage: {
    width: 42,
    height: 42,
    marginBottom: 4,
  },
  catLabel: {
    fontSize: 10,
    lineHeight: 13,
    color: filterIconLabelColor,
    fontWeight: fonts.weights.medium,
    textAlign: 'center',
  },
  empty: {
    borderStyle: 'dashed',
    borderColor: '#e6dfc8',
    borderRadius: radius.md,
    padding: 20,
    alignItems: 'center',
  },
  emptyText: {
    color: '#8a7a54',
    fontSize: 13,
    fontWeight: fonts.weights.bold,
  },
});
