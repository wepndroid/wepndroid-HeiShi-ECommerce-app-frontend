import * as ImagePicker from 'expo-image-picker';
import { Platform } from 'react-native';

export type PickedMedia = {
  uri: string;
  mimeType?: string;
  fileName?: string;
};

export const MAX_LISTING_PHOTOS = 9;

async function ensureLibraryPermission(): Promise<void> {
  if (Platform.OS === 'web') return;
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (status !== 'granted') {
    throw new Error('permission_denied');
  }
}

export async function pickImagesFromLibrary(options: {
  max?: number;
  allowsMultiple?: boolean;
}): Promise<PickedMedia[]> {
  await ensureLibraryPermission();

  const max = options.max ?? 1;
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsMultipleSelection: options.allowsMultiple ?? max > 1,
    selectionLimit: max,
    quality: 0.85,
  });

  if (result.canceled || !result.assets?.length) {
    return [];
  }

  return result.assets.slice(0, max).map((asset) => ({
    uri: asset.uri,
    mimeType: asset.mimeType ?? undefined,
    fileName: asset.fileName ?? undefined,
  }));
}