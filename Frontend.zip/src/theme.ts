import { Platform, StyleSheet, TextStyle, ViewStyle } from 'react-native';

/** 闲鱼-aligned palette (XIANYU_Style_Specification.md) */
export const colors = {
  bg: '#FFFFFF',
  paper: '#FFFFFF',
  card: '#FFFFFF',
  text: '#222222',
  sub: '#777777',
  muted: '#999999',
  line: '#EEEEEE',
  /** Xianyu CY0 / main_post_ball_color — vivid tab & publish yellow */
  brand: '#FFE60F',
  brand2: '#FFB415',
  /** Light brand tint for badges, avatars, highlights */
  brand3: '#FFFBEB',
  green: '#29AB91',
  red: '#FF4444',
  blue: '#108EE9',
  stage: '#EBEEEF',
  phoneBorder: '#111111',
  searchHint: '#9C9C9D',
  searchIcon: '#B2B2B2',
  placeholder: '#B3B3B3',
  loginBar: '#222222',
};

/** Compact radii — 闲鱼 uses 4–12dp cards, pills for search/buttons */
export const radius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  amazing: 8,
  pill: 999,
  phone: 38,
};

/** 16dp gutter; 56dp bottom nav */
export const spacing = {
  screenPadding: 16,
  screenBottomNav: 64,
  screenBottomNoNav: 24,
  statusHeight: 34,
  bottomNavHeight: 56,
};

/** AntUI-aligned type scale (sp) */
export const typography = {
  nav: 10,
  badge: 10,
  meta: 11,
  bodySm: 12,
  body: 14,
  section: 16,
  title: 17,
  priceFeed: 16,
  priceDetail: 24,
  hero: 20,
};

export const fonts = {
  regular: 'System',
  en: {
    regular: 'Inter_400Regular',
    medium: 'Inter_500Medium',
    bold: 'Inter_700Bold',
  },
  weights: {
    medium: '500' as const,
    bold: '700' as const,
  },
};

export const amazingStyleBg = '#FFFFFF';

/** Flat surface — 闲鱼 avoids card drop shadows */
export const amazingStyleShadow: ViewStyle = {
  shadowColor: 'transparent',
  shadowOffset: { width: 0, height: 0 },
  shadowOpacity: 0,
  shadowRadius: 0,
  elevation: 0,
};

/** No inset highlight on flat cards */
export const amazingStyleHighlight: ViewStyle = {
  display: 'none',
};

export const amazingStyle: ViewStyle = {
  backgroundColor: amazingStyleBg,
  borderRadius: radius.amazing,
  overflow: 'hidden',
  ...amazingStyleShadow,
};

export const amazingStylePill: ViewStyle = {
  backgroundColor: colors.paper,
  borderRadius: radius.pill,
  borderWidth: StyleSheet.hairlineWidth,
  borderColor: colors.line,
  overflow: 'hidden',
  ...amazingStyleShadow,
};

/** Category shortcut tile — flat white, no shadow */
export const filterIconTile: ViewStyle = {
  backgroundColor: colors.paper,
};

export const filterIconColor = colors.sub;
export const filterIconLabelColor = colors.text;

/** Search capsule — white fill + black outline */
export const searchBarSurface: ViewStyle = {
  backgroundColor: colors.paper,
  borderWidth: 2,
  borderColor: colors.phoneBorder,
  borderRadius: radius.pill,
  ...amazingStyleShadow,
};

/** Shared TextInput defaults — no focus ring / outline (especially on web). */
export const plainTextInput: TextStyle = {
  borderWidth: 0,
  backgroundColor: 'transparent',
  padding: 0,
  margin: 0,
  ...(Platform.OS === 'web'
    ? ({
        outlineStyle: 'none',
        outlineWidth: 0,
        outlineColor: 'transparent',
      } as TextStyle)
    : null),
};
