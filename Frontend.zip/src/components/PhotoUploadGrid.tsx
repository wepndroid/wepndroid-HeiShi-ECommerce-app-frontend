import React from 'react';
import { ActivityIndicator, Image, Pressable, StyleSheet, View } from 'react-native';
import { Text } from './typography';
import { useTranslation } from 'react-i18next';
import { AppIcon } from './AppIcon';
import { colors, fonts, radius } from '../theme';

type Props = {
  imageUrls: string[];
  onAdd: () => void;
  uploading?: boolean;
};

export function PhotoUploadGrid({ imageUrls, onAdd, uploading }: Props) {
  const { t } = useTranslation();

  return (
    <View style={styles.grid}>
      {imageUrls.map((uri) => (
        <View key={uri} style={styles.thumbWrap}>
          <Image source={{ uri }} style={styles.thumb} resizeMode="cover" />
        </View>
      ))}
      <Pressable style={styles.addBtn} onPress={onAdd} disabled={uploading}>
        {uploading ? (
          <ActivityIndicator color={colors.text} />
        ) : (
          <>
            <AppIcon name="camera" size={22} color={colors.sub} />
            <Text style={styles.addLabel}>{t('screens.publish.uploadBtn')}</Text>
          </>
        )}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  thumbWrap: {
    width: 88,
    height: 88,
    borderRadius: radius.md,
    overflow: 'hidden',
    backgroundColor: colors.stage,
  },
  thumb: {
    width: '100%',
    height: '100%',
  },
  addBtn: {
    width: 88,
    height: 88,
    borderRadius: radius.md,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: colors.line,
    backgroundColor: colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  addLabel: {
    fontSize: 10,
    color: colors.sub,
    fontWeight: fonts.weights.medium,
    textAlign: 'center',
  },
});