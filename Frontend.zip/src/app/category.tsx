export { CategoryScreen as default } from '../screens/CategoryScreen';
